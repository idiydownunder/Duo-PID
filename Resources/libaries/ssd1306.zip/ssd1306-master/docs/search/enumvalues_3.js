var searchData=
[
  ['vga_5fset_5fblock',['VGA_SET_BLOCK',['../vga__commands_8h.html#a6a3ce562f42b87c3763dd0cdd3f1dee2a85b2ea560661c4e81b3746fa463d6d51',1,'vga_commands.h']]],
  ['vga_5fset_5fmode',['VGA_SET_MODE',['../vga__commands_8h.html#a6a3ce562f42b87c3763dd0cdd3f1dee2a699dc4ba7ac890dffb99907e5d705d54',1,'vga_commands.h']]]
];
