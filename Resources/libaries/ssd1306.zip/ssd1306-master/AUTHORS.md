## Project Authors

* ssd1306 library is written by [Alexey Dynda](https://github.com/lexus2k).

## Contributors

* [MinusWall](https://github.com/minuswall)
* [drgallaci](https://github.com/drgallaci)
* [CromFr](https://gitbug.com/CromFr)
* [montaguk](https://github.com/montaguk)

## Special thanks to

* [Peter Scargill](https://github.com/scargill)
